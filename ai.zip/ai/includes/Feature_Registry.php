<?php
/**
 * Feature Registry class.
 *
 * @package WordPress\AI
 */

namespace WordPress\AI;

use WordPress\AI\Contracts\Feature;

/**
 * Central registry for managing feature storage and retrieval.
 *
 * Provides a simple storage mechanism for registered features.
 * Feature initialization is handled by the Feature_Loader class.
 *
 * @since 0.1.0
 */
class Feature_Registry {
	/**
	 * Registered features.
	 *
	 * @since 0.1.0
	 * @var \WordPress\AI\Contracts\Feature[]
	 */
	private $features = array();

	/**
	 * Registers a feature.
	 *
	 * @since 0.1.0
	 *
	 * @param \WordPress\AI\Contracts\Feature $feature Feature instance to register.
	 * @return bool True if registered successfully, false if already exists or invalid.
	 */
	public function register_feature( Feature $feature ): bool {
		$id = $feature->get_id();

		// Validate feature ID is not empty.
		if ( empty( $id ) ) {
			return false;
		}

		if ( $this->has_feature( $id ) ) {
			return false;
		}

		$this->features[ $id ] = $feature;
		return true;
	}

	/**
	 * Gets a feature by ID.
	 *
	 * @since 0.1.0
	 *
	 * @param string $id Feature identifier.
	 * @return \WordPress\AI\Contracts\Feature|null Feature instance or null if not found.
	 */
	public function get_feature( string $id ): ?Feature {
		return $this->features[ $id ] ?? null;
	}

	/**
	 * Gets all registered features.
	 *
	 * @since 0.1.0
	 *
	 * @return \WordPress\AI\Contracts\Feature[] Array of feature instances keyed by feature ID.
	 */
	public function get_all_features(): array {
		return $this->features;
	}

	/**
	 * Checks if a feature is registered.
	 *
	 * @since 0.1.0
	 *
	 * @param string $id Feature identifier.
	 * @return bool True if registered, false otherwise.
	 */
	public function has_feature( string $id ): bool {
		return isset( $this->features[ $id ] );
	}
}
